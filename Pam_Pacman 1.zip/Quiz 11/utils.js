// Random integer generator - "limit" can be replaced with any integer and it would produce a random number between 0-1 * that number inputted
function randomInt(limit) {
  return Math.round(Math.random() * limit)
}

// Random color processing
function makeRGB(r2, g2, b2) {
  // Process
  let r = r2 ?? randomInt(255)
  let g = g2 ?? randomInt(255)
  let b = b2 ?? randomInt(255)
  
  // Output
  return `rgb(${r}, ${g}, ${b})`
}

// Yellow only
function yellow(r, g, b) {
  // Process
  let r3 = "255"
  let g3 = "238"
  let b3 = "0"
  
  // Output
  return `rgb(${r3}, ${g3}, ${b3})`
}

// Gray only
function gray(r, g, b) {
  // Process
  let r4 = "222"
  let g4 = "214"
  let b4 = "204"
  
  // Output
  return `rgb(${r4}, ${g4}, ${b4})`
}