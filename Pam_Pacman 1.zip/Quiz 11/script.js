const svg = document.getElementById("base-svg");

window.addEventListener("resize", resizeSvg);

function resizeSvg(){
    let bbox = svg.getBoundingClientRect();
    svg.setAttribute("viewBox", `0 0 ${bbox.width} ${bbox.height}`);
}

// SVG canvas
let width = innerWidth
let height = innerHeight

svg.setAttribute("width", "100%");
svg.setAttribute("height", "100%");

// Pacman food
function food(cx, cy, r, colour) {
    let food = document.createElementNS("http://www.w3.org/2000/svg", "circle")
    food.setAttribute("cx", cx);
    food.setAttribute("cy", cy);
    food.setAttribute("r", r);
    food.setAttribute("fill", colour);
    svg.appendChild(food)

}

// All functions will start materializing here

// Food on x-axis
food(0, 100, 15, makeRGB())
food(100, 100, 15, makeRGB())
food(200, 100, 15, makeRGB())
food(300, 100, 15, makeRGB())
food(400, 100, 15, makeRGB())
food(500, 100, 15, makeRGB())
food(600, 100, 15, makeRGB())

// Food on y-axis
food(100, 0, 15, makeRGB())
food(100, 100, 15, makeRGB())
food(100, 200, 15, makeRGB())
food(100, 300, 15, makeRGB())
food(100, 400, 15, makeRGB())
food(100, 500, 15, makeRGB())
food(100, 600, 15, makeRGB())